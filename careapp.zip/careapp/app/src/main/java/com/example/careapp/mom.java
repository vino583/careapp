package com.example.careapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class mom extends AppCompatActivity {
    Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mom);
        b1=(Button) findViewById(R.id.week1);
        b2=(Button)findViewById(R.id.week2);
        b3=(Button)findViewById(R.id.week3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), week.class);
                startActivity(i);
                Toast.makeText(getApplicationContext(), "loading", Toast.LENGTH_LONG).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), week2.class);
                startActivity(i);
                Toast.makeText(getApplicationContext(), "loading", Toast.LENGTH_LONG).show();

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), week3.class);
                startActivity(i);
                Toast.makeText(getApplicationContext(), "loading", Toast.LENGTH_LONG).show();


            }
        });


    }
}