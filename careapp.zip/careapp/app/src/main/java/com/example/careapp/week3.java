package com.example.careapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class week3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_week3);
    }
}